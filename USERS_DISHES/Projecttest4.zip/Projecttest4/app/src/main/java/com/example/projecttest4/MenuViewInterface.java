package com.example.projecttest4;

public interface MenuViewInterface {
    void onDishClick(int position);
}
